# DucksInARow Mod for Cities Skylines 2

## Overview
Welcome to the "DucksInARow" mod for Cities Skylines 2, version v0.0.3. This cutting-edge mod enhances your city-building experience with advanced prop and tree placement options, continuously evolving with new features and improvements.

### Latest Features in Update
- **Better Placement**: Removal of oddities from the previous version for cleaner implementation.
- **Line Visualization**: Visual aids for linear prop placement, enhancing accuracy and aesthetics.
- **Corrected Random Rotation**: Natural and varied prop arrangements with improved rotation logic.
- **Curve and Circle Modes**: New modes for props in curved or circular patterns, toggled with ALT+X in tree tool.
- **Adult Tree Toggle**: ALT+A toggles between adult and sapling tree placements for varied forestry.
- **Right-Click to Cancel**: Easily cancel operations with a right-click, enhancing workflow.
- **Finer Spacing Adjustment**: Precise control over spacing between props.
- **Optimised Generation**: Limited generation per frame for better performance.
- **Bug Fixes and Optimizations**: Several improvements for a smoother experience.
- **More to Come**: Future updates and enhancements are planned.
- **Line Placement of Props**: Align props in a straight line with 8-meter default spacing.
- **No UI Yet**: Console log output for tracking, UI in future updates.
- **Dependency**: Requires BepInEx5 for functionality.

### Key Shortcuts
- **LEFT SHIFT**: Toggle mod functionality in tree placement tool.
- **UP/DOWN ARROWS**: Adjust prop spacing.
- **ALT+X**: Cycle through tree placement modes.
- **ALT+A**: Toggle between adult and sapling trees.

## Installation
Install BepInEx5 in Cities Skylines 2. Download "DucksInARow" from Thunderstore.io or the [official GitHub repository](https://github.com/Cities2Modding/DucksInARow).

## Usage
1. Activate the tree placement tool.
2. Use LEFT SHIFT to toggle the mod.
3. Place trees and adjust with key shortcuts.

## Community and Support
- **Reddit**: [Cities2Modding Subreddit](https://www.reddit.com/r/cities2modding/)
- **Discord**: [Cities2Modding Discord Server](https://discord.gg/KGRNBbm5Fh)

## Important Notes
- **Experimental Phase**: The mod is rudimentary and under active development.
- **Official Downloads**: Only download from Thunderstore.io or the official GitHub page.
- **Community Effort**: Created by the Cities 2 Modding community.

## Disclaimer
Due to Cities Skylines 2's validation logic, prop placements may be hidden by the game. We aim for accuracy but cannot guarantee perfect results. Feedback is appreciated for continuous improvement.

---

Enjoy "DucksInARow" and look forward to enhancing your city-building experience in Cities Skylines 2 with more updates and features!
